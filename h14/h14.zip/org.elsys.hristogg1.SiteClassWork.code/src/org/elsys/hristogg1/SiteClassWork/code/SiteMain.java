package org.elsys.hristogg1.SiteClassWork.code;

public class SiteMain {
	public static void main(String[] args) {
		Site site = new Site();
		site.getCertificate();
	
		Page page = new Page();
		page.linkDownload();
		
		Link link = new Link();
		link.download();
	}
}
