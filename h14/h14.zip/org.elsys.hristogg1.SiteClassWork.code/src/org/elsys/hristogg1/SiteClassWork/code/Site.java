package org.elsys.hristogg1.SiteClassWork.code;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class Site {
	private String certificate;

	public void getCertificate() {
		try {
			
			
			URL url = new URL ("http://www.kodejava.org");
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					url.openStream()));

			String line = url.toString();
			String http = "http";
			String https = "https";
			if (line.contains(http)) {
				certificate = http;
			}
			if (line.contains(https)) {
				certificate = https;
			}

			System.out.println(certificate);
			reader.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
