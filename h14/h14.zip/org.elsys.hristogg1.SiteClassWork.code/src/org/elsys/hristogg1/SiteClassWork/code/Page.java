package org.elsys.hristogg1.SiteClassWork.code;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.MalformedURLException;

public class Page {
	private String content;
	private int links;

	public void linkDownload() {
		try {
			URL url = new URL("http://www.kodejava.org");

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					url.openStream()));
	
			String line;
			String href = "<a href=";
			links = 0;
			while ((line = reader.readLine()) != null) {
				content += line;
				line.toLowerCase();
				if(line.contains(href)){
					links += 1;
				}
			}
			System.out.println(links);

			reader.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
