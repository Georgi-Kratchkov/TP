package org.elsys.hristogg1.SiteClassWork.code;

public class SiteMain {
	public static void main(String[] args) {
		Site BgPravopis = new Site();
		BgPravopis.setUrl("http://www.kodejava.org");
		
	}
}
