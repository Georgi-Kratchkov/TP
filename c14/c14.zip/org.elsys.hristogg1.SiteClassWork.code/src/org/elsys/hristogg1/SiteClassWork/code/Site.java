package org.elsys.hristogg1.SiteClassWork.code;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class Site {
	private URL url;
	private String certificate;
	private String pages;

	public URL getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = new URL(url);
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public String getPages() {
		return pages;
	}

	public void setPages(String pages) {
		this.pages = pages;
	}

	public void certificate() {
		try {

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					url.openStream()));

			String line = url.toString();
			String http = "http";
			String https = "https";
			if (line.contains(http)) {
				certificate = http;
			}
			if (line.contains(https)) {
				certificate = https;
			}

			reader.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
