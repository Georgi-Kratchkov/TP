package org.elsys.hristogg1.SiteClassWork.code;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.MalformedURLException;

public class Page {
	private String content;
	private String url;
	private int links;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getLinks() {
		return links;
	}

	public void setLinks(int links) {
		this.links = links;
	}

	public void linkDownload() {
		try {
			URL url = new URL("http://www.kodejava.org");

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					url.openStream()));
	
			String line;
			String href = "<a href=";
			links = 0;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
				content += line;
				line.toLowerCase();
				if(line.contains(href)){
					links += 1;
				}
			}

			reader.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
