package org.elsys.hristogg1.SiteClassWork.code;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.MalformedURLException;

public class Link {
	private String value;
	private String download;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDownload() {
		return download;
	}

	public void setDownload(String download) {
		this.download = download;
	}

	public void download() {
		try {
			URL url = new URL("http://www.kodejava.org");

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					url.openStream()));
			BufferedWriter writer = new BufferedWriter(new FileWriter(
					"data.html"));

			String line;
			while ((line = reader.readLine()) != null) {
				// System.out.println(line);
				writer.write(line);
				writer.newLine();
			}

			reader.close();
			writer.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
