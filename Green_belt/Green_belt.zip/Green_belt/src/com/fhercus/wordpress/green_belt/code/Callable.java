package com.fhercus.wordpress.green_belt.code;

public interface Callable {
	public void call();
}
