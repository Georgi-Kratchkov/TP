package com.fhercus.wordpress.green_belt.code;

public class Computer extends Machine {

	public Computer (int voltage){
		super(voltage);
		
	}
}
