package com.fhercus.wordpress.green_belt.code;

import java.util.ArrayList;

public class Machine {

	private int voltage;
	
	public Machine(int voltage){
		
		this.voltage = voltage;
	}

	public int getVoltage() {
		return voltage;
	}

	public void setVoltage(int voltage) {
		this.voltage = voltage;
	}
	
	public void print(ArrayList<Machine> mList) {
		for(Machine m : mList){
			System.out.println("The voltage is: " + m.getVoltage());
		}
	}
	
}
