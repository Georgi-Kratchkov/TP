package com.fhercus.wordpress.green_belt.code;

import java.util.Scanner;
import java.util.ArrayList;


public class Main1 {

	public static void main(String[] args) {
	
		ArrayList<Machine> mList = new ArrayList<Machine>();
		Scanner in = new Scanner(System.in);
		
		
		for(int a=0; a<5; a++){
			System.out.println("Enter voltage: ");
			
			String control = in.next().toString();
			
			String  [] control1 = control.split(",");
			int i = Integer.parseInt(control1[1]);
			if (control1[0].equals("p")){
				Phone p = new Phone (i);
				
				mList.add(p);			
				p.print(mList);
			}
			if (control1[0].equals("c")) {
				
				Computer c = new Computer(i);
				mList.add(c);
				c.print(mList);
			}
		}
		
		int voltage = in.nextInt();
		for(Machine m : mList){
			if(m instanceof Phone){	
				if(voltage == m.getVoltage()){
					((Phone)m).call();
				}
			}	
		}
		
		Phone p = new Phone(6);
		
		p.print(mList);
		
		in.close();
		
		
	}

}
