package com.fhercus.wordpress.green_belt.code;

public class Phone extends Machine implements Callable {
	
	public Phone (int voltage){
		
		super(voltage);
	}
	
	public void call(){
		int up;
		up = super.getVoltage();
		up = up * 2;
		super.setVoltage(up);
	}
}
