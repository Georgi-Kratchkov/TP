package com.wordpress.fhercus.evaluator.code;

public interface IEvaluator {
	void add(double d);
	
	Double evaluate();
}
