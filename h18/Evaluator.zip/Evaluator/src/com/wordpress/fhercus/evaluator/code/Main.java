package com.wordpress.fhercus.evaluator.code;

public class Main implements IEvaluatorFactory{
	
	public IEvaluators createSumEvaluator() {
		IEvaluators eval = new IEvaluators();
		return eval;
	}
	
	public IEvaluators createPowerOnEvaluator() {
		IEvaluators eval = new PowerOnEvaluator(2);
		return eval;
	}
	
	public IEvaluators createPowerOnEvaluator(int power) {
		IEvaluators eval = new PowerOnEvaluator(power);
		return eval;
	}
	
	public IEvaluators createFibonachiEvaluator() {
		IEvaluators eval = new FibonachiEvaluator();
		return eval;
	}
	
	public static void main(String[] args) {
		IEvaluatorFactory evalFactory = new Main(); 
		IEvaluators eval = evalFactory.createSumEvaluator();
		eval.add(2);
		eval.add(2);
		eval.add(2);
		System.out.println(eval.evaluate());
		
		IEvaluators eval1 = evalFactory.createPowerOnEvaluator();
		eval1.add(2);
		eval1.add(2);
		eval1.add(2);
		System.out.println(eval1.evaluate());
		
		IEvaluators eval2 = evalFactory.createPowerOnEvaluator(3);
		eval2.add(2);
		eval2.add(2);
		eval2.add(2);
		System.out.println(eval2.evaluate());
		
		IEvaluators eval3 = evalFactory.createFibonachiEvaluator();
		eval3.add(2);
		eval3.add(2);
		eval3.add(2);
		System.out.println(eval3.evaluate());
	}

}
