package com.wordpress.fhercus.evaluator.code;

public interface IEvaluatorFactory {
	public IEvaluators createSumEvaluator();
	
	public IEvaluators createPowerOnEvaluator();
	
	public IEvaluators createPowerOnEvaluator(int power);
	
	public IEvaluators createFibonachiEvaluator();
}
